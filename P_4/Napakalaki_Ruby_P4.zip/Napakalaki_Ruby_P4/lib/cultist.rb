

class Cultist
    
    attr_reader :gainedLevels
  
    # Constructor
    def initialize(name, level)
        @name = name
        @gainedLevels = level
    end
end
