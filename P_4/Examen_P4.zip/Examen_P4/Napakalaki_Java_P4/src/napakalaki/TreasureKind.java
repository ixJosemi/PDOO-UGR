// MADE BY: JOSE MIGUEL HDEZ GARCIA & JAIRO ABRIL MOYA

package napakalaki;

// Enumeración de los tipos de tesoros TreasureKind
public enum TreasureKind {ARMOR, ONEHAND, BOTHHANDS, HELMET , SHOES};
