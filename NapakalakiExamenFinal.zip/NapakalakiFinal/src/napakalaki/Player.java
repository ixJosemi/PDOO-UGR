/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import GUI.Dice;
import java.util.ArrayList;
import napakalaki.Treasure;

/**
 *
 * @author antoniojj
 */
public class Player {

    static final int MAXLEVEL = 10;
    private String name;
    private int level;
    private boolean dead = true;
    private boolean canISteal = true;
    private ArrayList<Treasure> hiddenTreasures = new ArrayList();
    private ArrayList<Treasure> visibleTreasures = new ArrayList();
    protected Player enemy;
    private BadConsequence pendingBadConsequence; 

    public ArrayList<Treasure> getHiddenTreasures() {
        return hiddenTreasures;
    }

    public ArrayList<Treasure> getVisibleTreasures() {
        return visibleTreasures;
    }
    
    public Player(Player p){
        name = p.name;
        level = p.level;
        pendingBadConsequence = p.pendingBadConsequence;
        enemy = p.enemy;
        hiddenTreasures = p.hiddenTreasures;
        visibleTreasures = p.visibleTreasures;
    }
    ////////////////////////////////////////////////////////////////////////////
    public Player(String name) {
        this.name = name;
        level = 1;
        pendingBadConsequence = null;
        enemy = null;
    }
    ////////////////////////////////////////////////////////////////////////////
    public boolean isDead(){
        return dead;
    }
    ////////////////////////////////////////////////////////////////////////////
    public String getName() {
        return name;
    }
    ////////////////////////////////////////////////////////////////////////////
    public int getCombatLevel() {
        int nivelTotal = level;
        for( int i=0; i<visibleTreasures.size(); i++)
        {
            nivelTotal += visibleTreasures.get(i).getBonus();
        }
        return nivelTotal;
    }
    ////////////////////////////////////////////////////////////////////////////
    public void bringToLife(){
        dead = false;
    }
    ////////////////////////////////////////////////////////////////////////////
    public void incrementLevels(int niveles){
        level += niveles;
    }
    ////////////////////////////////////////////////////////////////////////////
    public void decrementLevels(int niveles){
        level -= niveles;
        if (this.level <= 1)
            this.level = 1;
    }
    ////////////////////////////////////////////////////////////////////////////
    public void setPendingBadConsequence(BadConsequence b){
        pendingBadConsequence = b;
        
    }
    ////////////////////////////////////////////////////////////////////////////
    public void dieIfNoTreasures(){
        if (visibleTreasures.isEmpty() && hiddenTreasures.isEmpty())
        {
            dead = true;
        }
    }
    ////////////////////////////////////////////////////////////////////////////
    public boolean validState(){
        if(pendingBadConsequence != null)
            return (pendingBadConsequence.isEmpty() && (hiddenTreasures.size()<4));
        else
            return true;
    }
    ////////////////////////////////////////////////////////////////////////////
    public int howManyVisibleTreasures(TreasureKind tKind){
        int contador = 0;
        for(int i=0;i<visibleTreasures.size();i++)
        {
            if(visibleTreasures.get(i).getType() == tKind)
                contador++;
        }
        return contador;
    }
    ////////////////////////////////////////////////////////////////////////////
    public int getLevels(){
        return level;
    }
    ////////////////////////////////////////////////////////////////////////////
    public void setEnemy(Player enemy){
        this.enemy=enemy;
    }
    ////////////////////////////////////////////////////////////////////////////
    public boolean canISteal(){
        return canISteal;
    }
    ////////////////////////////////////////////////////////////////////////////
    public void haveStolen(){
        canISteal=false;
    }
    ////////////////////////////////////////////////////////////////////////////
    protected boolean canYouGiveMeATreasure(){
        return ((!visibleTreasures.isEmpty())||(!hiddenTreasures.isEmpty()));
    }
    ////////////////////////////////////////////////////////////////////////////
    private boolean canMakeTreasureVisible(Treasure t){
        boolean canBeVisible=true;
        
        if(this.visibleTreasures.size() < 4){
        TreasureKind tKind = t.getType();
      
        switch (tKind){
            case BOTHHANDS :
                int h=0;
                int btam = visibleTreasures.size();
                Treasure btes;
                while(h< btam && canBeVisible){
                    btes = visibleTreasures.get(h);
                    canBeVisible = !( btes.getType() == tKind || btes.getType() == TreasureKind.ONEHAND );
                    h++;
                }
            break;
            case ONEHAND :
                       canBeVisible = ((howManyVisibleTreasures(tKind) < 2) && 
                      (howManyVisibleTreasures(TreasureKind.BOTHHANDS) == 0));
            break;
            default:
                int j=0;
                int dtam = visibleTreasures.size();
                Treasure dtes;
                while(j< dtam && canBeVisible){
                    dtes = visibleTreasures.get(j);
                    canBeVisible = !(dtes.getType() == tKind);
                    j++;
                }
            break;
        }
        }
        return canBeVisible;
    }
    public void discardRandomVisible(){
        
        int posAleatoria = (int)(Math.random()* visibleTreasures.size());
        visibleTreasures.remove(posAleatoria);
    }
    
    public void discardRandomHidden(){
        
        int posAleatoria = (int)(Math.random()* hiddenTreasures.size());
        hiddenTreasures.remove(posAleatoria);
    }
    ////////////////////////////////////////////////////////////////////////////
    protected Treasure giveMeATreasure(){
        
        Treasure perdido;
        int posAleatoria = (int)(Math.random()* hiddenTreasures.size());
        perdido = hiddenTreasures.get(posAleatoria);
        hiddenTreasures.remove(posAleatoria);
        return perdido;
    }
    ////////////////////////////////////////////////////////////////////////////
    public void applyBadConsequence (Monster m) {
        
        BadConsequence badConsequence = m.getBadConsequence();
       
        int nLevels = badConsequence.getLevels(); 

        decrementLevels(nLevels); 

        pendingBadConsequence = badConsequence.adjustToFitTreasureLists(visibleTreasures,hiddenTreasures); 

        setPendingBadConsequence(pendingBadConsequence);
        
        pendingBadConsequence.applyBadConsequence(this);
    }
    ////////////////////////////////////////////////////////////////////////////
    public void applyPrize(Monster m) {

        int nLevels = m.getLevelsGained();

        this.incrementLevels(nLevels);

        int nTreasures = m.getTreasuresGained();

        if (nTreasures > 0) {

            CardDealer dealer = CardDealer.getInstance();

            for (int i = 1; i <= nTreasures; i++) {

                Treasure t = dealer.nextTreasure();
                hiddenTreasures.add(t);

            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////
    public CombatResult combat(Monster m){
        
        CombatResult combatResult;
        
        int myLevel = getCombatLevel();
        int monsterLevel = m.getCombatLevel();
        
        if(myLevel > monsterLevel){
            applyPrize(m);
            
            if(getLevels() >= MAXLEVEL)
                combatResult = CombatResult.WINGAME;
           
            else
                combatResult = CombatResult.WIN;            
        }
        else{
            applyBadConsequence(m);
  
            combatResult = CombatResult.LOSE;
        }   
        
        if (combatResult == CombatResult.LOSE){
            boolean should;
            should = shouldConvert();
            if(should){
                combatResult = CombatResult.LOSEANDCONVERT;
            }
        }
        return combatResult;
    }
    ////////////////////////////////////////////////////////////////////////////
 
    ////////////////////////////////////////////////////////////////////////////
     public void discardVisibleTreasure(Treasure t){
        
        visibleTreasures.remove(t);
        
        if(pendingBadConsequence != null && !(pendingBadConsequence.isEmpty()))
            pendingBadConsequence.substractVisibleTreasures(t);
        
        dieIfNoTreasures();
    }
    ////////////////////////////////////////////////////////////////////////////
    public void discardHiddenTreasure(Treasure t){
        
        hiddenTreasures.remove(t);
        
        if(pendingBadConsequence != null && !(pendingBadConsequence.isEmpty()))
            pendingBadConsequence.substractHiddenTreasures(t);
        
        dieIfNoTreasures();
    }
    ////////////////////////////////////////////////////////////////////////////
    public void initTreasures(){
        
        CardDealer dealer = CardDealer.getInstance();
      
        Dice dice = Dice.getInstance();
        
        bringToLife();
        
        Treasure treasure = dealer.nextTreasure();
        hiddenTreasures.add(treasure);
        
        int number = dice.nextNumber();
        
        if (number > 1){
            treasure = dealer.nextTreasure();
            hiddenTreasures.add(treasure);
        } 
        
        if (number == 6){
            treasure = dealer.nextTreasure();
            hiddenTreasures.add(treasure);
        }
    }
    ////////////////////////////////////////////////////////////////////////////
    public void makeTreasureVisible(Treasure t){
        
        if(canMakeTreasureVisible(t)){
            visibleTreasures.add(t);
            hiddenTreasures.remove(t);
        }
    }
    ////////////////////////////////////////////////////////////////////////////
     public Treasure stealTreasure(){
        
        Treasure treasure = null;
        
        boolean canI = canISteal();
        
        if(canI){
            
            if(enemy.canYouGiveMeATreasure()){
                treasure = enemy.giveMeATreasure();
                
                hiddenTreasures.add(treasure);
                
                haveStolen();
            }
        }       
        return treasure;
    }
     ///////////////////////////////////////////////////////////////////////////
     public void discardAllTreasures(){
        
        ArrayList <Treasure> visibleCopy = new ArrayList(visibleTreasures);
        ArrayList <Treasure> hiddenCopy = new ArrayList(hiddenTreasures);
        
        for(Treasure t: visibleCopy)
            discardVisibleTreasure(t);
        
        for(Treasure t: hiddenCopy)
            discardHiddenTreasure(t);
    }
     ///////////////////////////////////////////////////////////////////////////
     protected int getOponentLevel(Monster m){
         return  m.getCombatLevel();
     }
     ///////////////////////////////////////////////////////////////////////////
     protected boolean shouldConvert(){
        Dice toConvert = Dice.getInstance();
        if(toConvert.nextNumber()== 6)
               return true;
        else
            return false;
     }
     ///////////////////////////////////////////////////////////////////////////
     /*protected int getCombatLevel(){
         
     }
*/
    public static int getMAXLEVEL() {
        return MAXLEVEL;
    }

    public int getLevel() {
        return level;
    }

    public boolean isCanISteal() {
        return canISteal;
    }

    public Player getEnemy() {
        return enemy;
    }

    public BadConsequence getPendingBadConsequence() {
        return pendingBadConsequence;
    }
    
    public String IsCultist(){
        return "No";
    }
    
    // EXAMEN
    public boolean JokerVisible(){
        boolean es_visible = false;
        
        for (Treasure t: visibleTreasures){
            
            if (t.getType() == TreasureKind.JOKER)
                es_visible = true;     
        }
        
        return es_visible;
    }
    
    public void AplicarJoker(){
        // Ponemos la badconsequence a nulo
        this.setPendingBadConsequence(new NumericBadConsequence("",0,0,0));
        
        // Descartamos el joker
        this.discardVisibleTreasure(visibleTreasures.get(0));  
    }
      
     
}
