#encoding: utf-8
# MADE BY: JOSE MIGUEL HDEZ GARCIA & JAIRO ABRIL MOYA

module CombatResult
    WINGAME = :wingame
    WIN = :win
    LOSE = :lose
end
