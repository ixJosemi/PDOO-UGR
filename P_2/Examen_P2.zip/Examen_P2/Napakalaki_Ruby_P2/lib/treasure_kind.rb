# encoding: utf-8
# MADE BY: JOSE MIGUEL HDEZ GARCIA & JAIRO ABRIL MOYA

module TreasureKind
    ARMOR = :armor
    HELMET = :helmet
    SHOES = :shoes
    ONEHAND = :onehand
    BOTHHANDS = :bothhands
end
