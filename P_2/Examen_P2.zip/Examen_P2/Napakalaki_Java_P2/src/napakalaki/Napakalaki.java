// MADE BY: JOSE MIGUEL HDEZ GARCIA & JAIRO ABRIL MOYA

package napakalaki;

/**
 *
 * @author ixjosemi
 */

public class Napakalaki {
    
    private static Napakalaki instance = null;
    
    private Napakalaki(){
        
    }
    
    private void initPlayers(String names){
        
    }
    
    /*
    private Player nextPlayer(){
        
    }
    
    private boolean nextTurnAllowed(){
        
    }
    
    */
    private void SetEnemies(){
        
    }
    
    Napakalaki getInstance(){
        return instance;
    }
    
    /*
    public CombatResult developCombat(){
        
    }
    */
    
    public void discardVisibleTreasure(Treasure treasures){
        
    }
    
    public void discardHiddenTreasure(Treasure treasures){
        
    }
    
    private void makeTreasuresVisible(Treasure treasures){
        
    }
    
    public void initGame(String players){
        
    }
    
    /*
    public Player getCurrentPlayer(){
        
    }
    
    public Monster getCurrentMonster(){
        
    }
    
    public boolean nextTurn(){
        
    }
    
    public boolean endOfGame(CombatResult result){
        
    }
    */
}
